import { ChevronLeft, Plus } from "lucide-react";
import { decemberEvents, type CalendarEvent } from "~/lib/calendarEvents";

const DAYS_OF_WEEK = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"];
const MONTH_NAME = "DECEMBER";
const YEAR = 2025;

// December 2025 starts on a Monday (index 1)
const getMonthData = () => {
  const firstDayOfMonth = new Date(YEAR, 11, 1).getDay();
  const daysInMonth = new Date(YEAR, 12, 0).getDate();

  const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);
  const emptyDays = Array.from({ length: firstDayOfMonth }, (_, i) => null);

  const eventsByDate = decemberEvents.reduce((acc, event) => {
    acc[event.date] = event;
    return acc;
  }, {} as Record<number, CalendarEvent>);

  return {
    allDays: [...emptyDays, ...days],
    eventsByDate,
  };
};

const Polaroid = ({ event }: { event: CalendarEvent }) => (
  <article
    className="absolute inset-0 flex items-center justify-center z-10"
    style={{ transform: `rotate(${event.rotation}deg)` }}
  >
    <div className="relative bg-white p-2 pb-8 rounded-md shadow-lg filter drop-shadow-lg w-32 md:w-40">
      <div
        className={`absolute -top-2 left-1/2 -translate-x-1/2 w-12 h-5 ${event.tapeColor} backdrop-blur-sm border-b border-white/20`}
        style={{ transform: "rotate(-4deg)" }}
      />
      <img
        src={event.logo}
        alt={`${event.college} logo`}
        className="w-full h-auto aspect-square object-cover bg-sand"
      />
      <p className="absolute bottom-2 left-0 right-0 text-center text-sm font-medium text-chocolate-light">
        {event.college}
      </p>
    </div>
  </article>
);

export function MonthlyCalendar() {
  const { allDays, eventsByDate } = getMonthData();

  return (
    <div className="w-full max-w-5xl mx-auto p-4 md:p-8">
      <div className="bg-calendar-card-bg rounded-3xl shadow-calendar-card p-4 sm:p-6 bg-paper-texture">
        {/* Header */}
        <header className="relative flex items-center justify-between p-2">
          <div className="flex items-center gap-2">
            <button className="p-1.5 text-calendar-header/80 hover:text-calendar-header">
              <ChevronLeft size={24} />
            </button>
            <button className="p-1.5 text-calendar-header/80 hover:text-calendar-header">
              <Plus size={24} />
            </button>
          </div>
          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-center">
            <h1 className="font-serif font-bold text-4xl md:text-6xl text-calendar-header tracking-wide">
              {MONTH_NAME}
            </h1>
            <p className="text-sm text-gray-400 mt-1">The College Calendar</p>
          </div>
          <div className="w-10 h-10 bg-sand rounded-full flex items-center justify-center font-bold text-primary-dark">
            H
          </div>
        </header>

        {/* Grid */}
        <div className="mt-4 grid grid-cols-7 gap-px bg-gray-200 border border-gray-200 rounded-lg overflow-hidden">
          {DAYS_OF_WEEK.map((day) => (
            <div
              key={day}
              className="text-center py-3 bg-white/50 text-xs font-medium text-gray-500"
            >
              {day}
            </div>
          ))}

          {allDays.map((day, index) => {
            const event = day ? eventsByDate[day] : undefined;
            return (
              <div
                key={index}
                className="relative aspect-square bg-white p-2"
              >
                {day && (
                  <span
                    className={`text-sm ${
                      event ? "font-bold text-primary-dark" : "text-gray-400"
                    }`}
                  >
                    {day}
                  </span>
                )}
                {event && <Polaroid event={event} />}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
