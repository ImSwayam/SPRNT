import { Link, useLocation } from "@remix-run/react";
import {
  Calendar,
  LayoutGrid,
  LogIn,
  Ticket,
  Users,
  Wallet,
  Share2,
  Home,
  PlusCircle,
} from "lucide-react";
import clsx from "clsx";

const studentLinks = [
  { name: "Discover", href: "/discover", icon: Ticket },
  { name: "Clubs", href: "/clubs", icon: Users },
  { name: "Wallet", href: "/wallet", icon: Wallet },
];

const organiserLinks = [
  { name: "Overview", href: "/organiser-overview", icon: LayoutGrid },
  { name: "Schedule", href: "/schedule", icon: Calendar },
  { name: "Add Event", href: "/add-event", icon: PlusCircle },
  { name: "Social", href: "/organiser-social", icon: Share2 },
  { name: "Sign Up", href: "/organiser-signup", icon: LogIn },
];

export function Sidebar() {
  const { pathname } = useLocation();

  return (
    <aside className="w-64 flex-shrink-0 bg-chocolate/10 p-4 flex flex-col gap-8">
      <Link to="/" className="flex items-center gap-2">
        <Home className="w-8 h-8 text-primary" />
      </Link>

      <nav className="flex flex-col gap-4">
        <div>
          <h2 className="text-sm font-semibold text-chocolate uppercase tracking-wider mb-2">
            For Students
          </h2>
          <ul className="space-y-1">
            {studentLinks.map((link) => (
              <li key={link.name}>
                <Link
                  to={link.href}
                  className={clsx(
                    "flex items-center gap-3 px-3 py-2 rounded-lg transition-colors",
                    pathname === link.href
                      ? "bg-primary text-white"
                      : "text-chocolate-light hover:bg-primary-light/20"
                  )}
                >
                  <link.icon className="w-5 h-5" />
                  <span>{link.name}</span>
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h2 className="text-sm font-semibold text-chocolate uppercase tracking-wider mb-2">
            For Organisers
          </h2>
          <ul className="space-y-1">
            {organiserLinks.map((link) => (
              <li key={link.name}>
                <Link
                  to={link.href}
                  className={clsx(
                    "flex items-center gap-3 px-3 py-2 rounded-lg transition-colors",
                    pathname === link.href
                      ? "bg-primary text-white"
                      : "text-chocolate-light hover:bg-primary-light/20"
                  )}
                >
                  <link.icon className="w-5 h-5" />
                  <span>{link.name}</span>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </nav>
    </aside>
  );
}
