import { useEventFormStore, TABS } from '~/store/eventFormStore';
import clsx from 'clsx';

export function TabNavigation() {
  const { activeTab, setActiveTab } = useEventFormStore();

  return (
    <nav className="w-full md:w-64 flex-shrink-0 pr-8">
      <ul className="space-y-2">
        {TABS.map((tabName, index) => (
          <li key={tabName}>
            <button
              onClick={() => setActiveTab(index)}
              className={clsx(
                'w-full text-left px-4 py-2.5 rounded-lg transition-all duration-200 flex items-center',
                activeTab === index
                  ? 'bg-primary text-white shadow-lg'
                  : 'text-chocolate-light hover:bg-primary-light/10 hover:text-primary-dark'
              )}
            >
              <span className={clsx(
                "w-6 h-6 rounded-full mr-3 flex items-center justify-center text-xs font-bold",
                activeTab === index ? 'bg-white/20 text-white' : 'bg-sand-dark/50 text-chocolate'
              )}>
                {index + 1}
              </span>
              {tabName}
            </button>
          </li>
        ))}
      </ul>
    </nav>
  );
}
