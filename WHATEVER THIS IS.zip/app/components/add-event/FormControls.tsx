import { useEventFormStore, TABS } from '~/store/eventFormStore';

export function FormControls() {
  const { activeTab, nextTab, prevTab } = useEventFormStore();
  const isFirstTab = activeTab === 0;
  const isLastTab = activeTab === TABS.length - 1;

  return (
    <div className="mt-8 pt-6 border-t border-sand-dark/50 flex items-center justify-between">
      <div>
        <button
          type="button"
          className="px-6 py-2 rounded-lg bg-white border border-sand-dark text-chocolate-light hover:border-chocolate-light transition"
        >
          Save as Draft
        </button>
      </div>
      <div className="flex items-center gap-4">
        {!isFirstTab && (
          <button
            type="button"
            onClick={prevTab}
            className="px-6 py-2 rounded-lg bg-sand-dark/50 text-chocolate hover:bg-sand-dark transition"
          >
            Previous
          </button>
        )}
        {!isLastTab ? (
          <button
            type="button"
            onClick={nextTab}
            className="px-8 py-2 rounded-lg bg-primary text-white hover:bg-primary-dark transition shadow-md"
          >
            Next
          </button>
        ) : (
           <button
            type="submit"
            className="px-8 py-2 rounded-lg bg-emerald-500 text-white hover:bg-emerald-600 transition shadow-md"
          >
            Publish
          </button>
        )}
      </div>
    </div>
  );
}
