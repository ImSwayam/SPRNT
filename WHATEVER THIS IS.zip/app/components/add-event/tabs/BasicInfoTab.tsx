// This is a simplified example for the first tab.
// In a real application, you would create a component for each tab.

export function BasicInfoTab() {
  // In a real implementation, you'd connect these inputs to the Zustand store.
  return (
    <div className="space-y-6">
      <div>
        <label htmlFor="event-title" className="block text-sm font-medium text-chocolate">Event Title</label>
        <input type="text" id="event-title" className="mt-1 block w-full px-3 py-2 bg-white border border-sand-dark rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" placeholder="e.g., Annual Tech Conference 2025" />
      </div>
      <div>
        <label htmlFor="event-category" className="block text-sm font-medium text-chocolate">Event Category</label>
        <select id="event-category" className="mt-1 block w-full pl-3 pr-10 py-2 bg-white border border-sand-dark rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary">
          <option>Conference</option>
          <option>Workshop</option>
          <option>Party</option>
          <option>Webinar</option>
          <option>Other</option>
        </select>
      </div>
      <div>
        <label htmlFor="short-description" className="block text-sm font-medium text-chocolate">Short Description</label>
        <textarea id="short-description" rows={4} className="mt-1 block w-full px-3 py-2 bg-white border border-sand-dark rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" placeholder="Briefly describe what your event is about."></textarea>
      </div>
       <div>
        <label htmlFor="event-tags" className="block text-sm font-medium text-chocolate">Event Tags / Keywords</label>
        <input type="text" id="event-tags" className="mt-1 block w-full px-3 py-2 bg-white border border-sand-dark rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary" placeholder="e.g., AI, Startups, Networking (comma-separated)" />
      </div>
    </div>
  );
}
