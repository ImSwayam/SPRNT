interface PlaceholderTabProps {
  title: string;
}

export function PlaceholderTab({ title }: PlaceholderTabProps) {
  return (
    <div className="flex items-center justify-center h-96 bg-sand-dark/20 rounded-xl border-2 border-dashed border-sand-dark/50">
      <div className="text-center">
        <h3 className="text-lg font-semibold text-chocolate">{title}</h3>
        <p className="text-sm text-chocolate-light mt-1">Form fields for this section will be implemented here.</p>
      </div>
    </div>
  );
}
