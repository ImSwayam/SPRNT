import { discoverEvents } from "~/lib/discoverEvents";
import type { MetaFunction } from "@vercel/remix";

export const meta: MetaFunction = () => {
  return [{ title: "Organiser Overview" }];
};

export default function OrganiserOverviewPage() {
  return (
    <div className="grid lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2 space-y-6">
        <h2 className="text-xl font-semibold text-primary-dark">Overview</h2>
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-primary-dark">
            Major events
          </h3>
          <div className="space-y-2">
            {discoverEvents.map((event) => (
              <div
                key={event.id}
                className="flex items-center justify-between rounded-xl bg-white/90 shadow-card border border-primary/5 px-3 py-2"
              >
                <div className="flex items-center gap-3">
                  <img
                    src={event.logo}
                    alt={event.festivalName}
                    className="h-8 w-8 rounded-md object-contain bg-sand"
                  />
                  <div>
                    <p className="text-xs text-slate-600 font-medium">
                      {event.festivalName} • {event.college}
                    </p>
                    <p className="text-[11px] text-slate-500">
                      {new Date(event.startDate).toLocaleDateString(
                        "en-GB"
                      )}{" "}
                      →{" "}
                      {new Date(event.endDate).toLocaleDateString("en-GB")}
                    </p>
                  </div>
                </div>
                <span className="text-[11px] text-primary-dark bg-primary-light/10 px-2 py-1 rounded-full">
                  {event.city}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
      <div className="lg:col-span-1 space-y-6">
        <h3 className="text-lg font-semibold text-primary-dark">
          Analytics
        </h3>
        <div className="bg-white/90 rounded-xl shadow-card border border-primary/5 p-4 text-center">
          <p className="text-slate-600">Analytics section untouched.</p>
        </div>
      </div>
    </div>
  );
}
