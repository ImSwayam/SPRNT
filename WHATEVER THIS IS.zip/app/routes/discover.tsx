import { discoverEvents } from "~/lib/discoverEvents";
import type { MetaFunction } from "@vercel/remix";

export const meta: MetaFunction = () => {
  return [{ title: "Discover Events" }];
};

export default function DiscoverEventsPage() {
  return (
    <section className="space-y-4">
      <header className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-primary-dark">
          Discover events
        </h2>
        {/* keep existing dropdown/filter, just make Mumbai the default in your data */}
      </header>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {discoverEvents.map((event) => (
          <article
            key={event.id}
            className="bg-white/90 rounded-xl shadow-card border border-primary/5 p-4 flex flex-col gap-3"
          >
            <div className="flex items-center gap-3">
              <img
                src={event.organiserLogo}
                alt={event.college}
                className="h-8 w-8 rounded-full object-contain bg-sand"
              />
              <div>
                <p className="text-xs uppercase tracking-wide text-primary-dark/70">
                  {event.college} • {event.city}
                </p>
                <h3 className="font-semibold text-slate-900">{event.name}</h3>
              </div>
            </div>

            <div className="flex flex-wrap gap-1">
              {event.tags.map((tag) => (
                <span
                  key={tag}
                  className="text-xs bg-primary-light/10 text-primary-dark px-2 py-1 rounded-full"
                >
                  {tag}
                </span>
              ))}
            </div>

            <div className="mt-auto flex items-center justify-between text-xs pt-2">
              <span className="text-slate-600">
                {new Date(event.startDate).toLocaleDateString("en-GB", {
                  day: "numeric",
                  month: "short",
                })}{" "}
                →{" "}
                {new Date(event.endDate).toLocaleDateString("en-GB", {
                  day: "numeric",
                  month: "short",
                  year: "numeric",
                })}
              </span>
              <span
                className={
                  event.status === "active"
                    ? "text-green-700 bg-green-100 px-2 py-1 rounded-full font-medium"
                    : "text-slate-500 bg-slate-100 px-2 py-1 rounded-full font-medium"
                }
              >
                {event.status === "active" ? "Tickets active" : "Past event"}
              </span>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
