import type { MetaFunction } from "@vercel/remix";

export const meta: MetaFunction = () => {
  return [{ title: "Organiser Schedule" }];
};

const DAYS = Array.from({ length: 31 }, (_, i) => i + 1); // 1..31
const DAY_NAMES = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export default function SchedulePage() {
  return (
    <div className="space-y-4 h-full max-h-[calc(100vh-3rem)] overflow-y-auto pr-2">
      <h2 className="text-lg font-semibold text-primary-dark">
        December 2026 schedule
      </h2>

      <div className="rounded-xl bg-white/90 shadow-card border border-primary/5 p-3">
        <div className="grid grid-cols-7 gap-2 text-xs text-center font-semibold text-chocolate mb-2">
          {DAY_NAMES.map((day) => (
            <div key={day}>{day}</div>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-2 text-xs">
          {/* December 2026 starts on a Tuesday, so we add 2 empty divs for Sun/Mon */}
          <div />
          <div />
          {DAYS.map((day) => (
            <div
              key={day}
              className="aspect-square rounded-lg border border-sand-dark/40 flex items-start justify-start p-1.5 text-slate-700 hover:bg-sand-dark/40 transition-colors"
            >
              {day}
            </div>
          ))}
        </div>
      </div>

      <div className="pt-4">
        <h3 className="text-md font-semibold text-primary-dark mb-2">
          Events in December 2026
        </h3>
        <div className="bg-white/90 rounded-xl shadow-card border border-primary/5 p-4 text-center">
          <p className="text-slate-600">
            Your existing event list/cards below here.
          </p>
        </div>
      </div>
    </div>
  );
}
