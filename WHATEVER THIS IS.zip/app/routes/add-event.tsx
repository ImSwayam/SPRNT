import type { MetaFunction } from "@vercel/remix";
import { useEventFormStore, TABS } from "~/store/eventFormStore";
import { TabNavigation } from "~/components/add-event/TabNavigation";
import { FormControls } from "~/components/add-event/FormControls";

// Import tab components
import { BasicInfoTab } from "~/components/add-event/tabs/BasicInfoTab";
import { PlaceholderTab } from "~/components/add-event/tabs/PlaceholderTab";

export const meta: MetaFunction = () => {
  return [{ title: "Add New Event" }];
};

const tabComponents = [
  <BasicInfoTab />,
  <PlaceholderTab title="Date & Time" />,
  <PlaceholderTab title="Location" />,
  <PlaceholderTab title="Tickets & Pricing" />,
  <PlaceholderTab title="Event Details" />,
  <PlaceholderTab title="Speakers & Team" />,
  <PlaceholderTab title="Design & Branding" />,
  <PlaceholderTab title="Settings & Privacy" />,
  <PlaceholderTab title="Integrations & Add-ons" />,
  <PlaceholderTab title="Review & Publish" />,
];

export default function AddEventPage() {
  const activeTab = useEventFormStore((state) => state.activeTab);

  return (
    <div className="p-4 sm:p-6 lg:p-8">
      <header className="mb-8">
        <h1 className="text-3xl font-bold font-serif text-primary-dark">Add New Event</h1>
        <p className="text-chocolate-light mt-1">Fill out the details below to create and publish your event.</p>
      </header>

      <div className="flex flex-col md:flex-row gap-8">
        <TabNavigation />
        
        <main className="flex-1">
          <div className="bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-card border border-primary/10">
            <h2 className="text-xl font-semibold text-chocolate mb-6 pb-4 border-b border-sand-dark/50">
              {TABS[activeTab]}
            </h2>
            
            <form onSubmit={(e) => e.preventDefault()}>
              {tabComponents[activeTab]}
              <FormControls />
            </form>
          </div>
        </main>
      </div>
    </div>
  );
}
