import { collegeClubs } from "~/lib/collegeClubs";
import type { MetaFunction } from "@vercel/remix";

export const meta: MetaFunction = () => {
  return [{ title: "College Clubs" }];
};

export default function ClubsPage() {
  return (
    <section className="space-y-4">
      <h2 className="text-xl font-semibold text-primary-dark">
        Clubs by college
      </h2>

      <div className="space-y-3">
        {collegeClubs.map((group) => (
          <div
            key={group.college}
            className="bg-white/90 rounded-xl shadow-card border border-primary/5 p-4"
          >
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold">{group.college}</h3>
                <p className="text-xs text-slate-600">{group.city}</p>
              </div>
            </div>

            <div className="mt-3 flex flex-wrap gap-2">
              {group.clubs.map((club) => (
                <button
                  key={club}
                  className="text-xs bg-primary-light/10 text-primary-dark px-3 py-1 rounded-full hover:bg-primary-light/20 transition-colors"
                >
                  {club}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
