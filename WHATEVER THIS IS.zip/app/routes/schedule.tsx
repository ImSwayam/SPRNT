import type { MetaFunction } from "@vercel/remix";
import { MonthlyCalendar } from "~/components/MonthlyCalendar";

export const meta: MetaFunction = () => {
  return [{ title: "Event Schedule" }];
};

export default function SchedulePage() {
  return (
    <div className="w-full min-h-full bg-calendar-bg flex items-center justify-center">
      <MonthlyCalendar />
    </div>
  );
}
