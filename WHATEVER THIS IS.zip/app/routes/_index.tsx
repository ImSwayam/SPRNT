import type { MetaFunction } from "@vercel/remix";
import { Link } from "@remix-run/react";

export const meta: MetaFunction = () => {
  return [{ title: "College Event Hub | Home" }];
};

export default function Index() {
  return (
    <div className="text-center space-y-8">
      <header className="bg-white/90 rounded-xl shadow-card border border-primary/5 p-8">
        <h1 className="text-4xl font-bold text-primary-dark mb-2">
          Welcome to the Event Hub
        </h1>
        <p className="text-lg text-chocolate">
          Your central hub for college fests and events.
        </p>
      </header>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-white/90 rounded-xl shadow-card border border-primary/5 p-6 space-y-4">
          <h2 className="text-2xl font-semibold text-primary-dark">
            For Students
          </h2>
          <p className="text-slate-600">
            Discover events, find clubs, and manage your tickets all in one
            place.
          </p>
          <Link
            to="/discover"
            className="inline-block bg-primary text-white rounded-xl px-6 py-2 hover:bg-primary-dark transition"
          >
            Discover Events
          </Link>
        </div>
        <div className="bg-white/90 rounded-xl shadow-card border border-primary/5 p-6 space-y-4">
          <h2 className="text-2xl font-semibold text-primary-dark">
            For Organisers
          </h2>
          <p className="text-slate-600">
            Manage your events, view analytics, and connect with your audience.
          </p>
          <Link
            to="/organiser-overview"
            className="inline-block bg-primary text-white rounded-xl px-6 py-2 hover:bg-primary-dark transition"
          >
            Go to Dashboard
          </Link>
        </div>
      </div>
    </div>
  );
}
