import { useState } from "react";
import type { MetaFunction } from "@vercel/remix";

export const meta: MetaFunction = () => {
  return [{ title: "Social Links" }];
};

type SocialType =
  | "instagram"
  | "facebook"
  | "twitter"
  | "linkedin"
  | "website";

const SOCIAL_LABELS: Record<SocialType, string> = {
  instagram: "Instagram",
  facebook: "Facebook",
  twitter: "Twitter / X",
  linkedin: "LinkedIn",
  website: "Website",
};

export default function OrganiserSocialPage() {
  const [links, setLinks] = useState<
    { id: number; type: SocialType; url: string }[]
  >([{ id: 1, type: "instagram", url: "" }]);

  const addLink = () =>
    setLinks((prev) => [
      ...prev,
      { id: Date.now(), type: "instagram", url: "" },
    ]);

  const updateLink = (id: number, field: "type" | "url", value: any) =>
    setLinks((prev) =>
      prev.map((l) => (l.id === id ? { ...l, [field]: value } : l))
    );

  const removeLink = (id: number) =>
    setLinks((prev) => prev.filter((l) => l.id !== id));

  return (
    <div className="space-y-4 h-full max-h-[calc(100vh-3rem)] overflow-y-auto pr-2">
      <h2 className="text-lg font-semibold text-primary-dark">Social links</h2>

      <form className="space-y-3">
        {links.map((link) => (
          <div
            key={link.id}
            className="flex flex-col gap-2 rounded-xl bg-white/90 shadow-card border border-primary/5 p-3 md:flex-row md:items-center"
          >
            <select
              className="rounded-lg border border-slate-200 bg-sand/40 px-3 py-2 text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary"
              value={link.type}
              onChange={(e) =>
                updateLink(link.id, "type", e.target.value as SocialType)
              }
            >
              {Object.entries(SOCIAL_LABELS).map(([value, label]) => (
                <option key={value} value={value}>
                  {label}
                </option>
              ))}
            </select>
            <input
              type="url"
              placeholder="https://instagram.com/yourclub"
              className="flex-1 rounded-lg border border-slate-200 bg-sand/40 px-3 py-2 text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary"
              value={link.url}
              onChange={(e) => updateLink(link.id, "url", e.target.value)}
            />
            <button
              type="button"
              onClick={() => removeLink(link.id)}
              className="text-xs text-red-600 hover:underline text-right md:text-center px-2"
            >
              Remove
            </button>
          </div>
        ))}
      </form>

      <div className="flex items-center gap-4">
        <button
          type="button"
          onClick={addLink}
          className="bg-primary text-white text-sm rounded-xl px-3 py-2 hover:bg-primary-dark transition-colors"
        >
          + Add social link
        </button>
        <button
          type="submit"
          className="bg-chocolate text-white text-sm rounded-xl px-4 py-2 hover:bg-chocolate-light transition-colors"
        >
          Save Changes
        </button>
      </div>

      <div className="pt-4">
        <h3 className="text-md font-semibold text-primary-dark mb-2">
          Advertising Preview
        </h3>
        <div className="bg-white/90 rounded-xl shadow-card border border-primary/5 p-4 text-center">
          <p className="text-slate-600">
            Advertising / preview part v0 created.
          </p>
        </div>
      </div>
    </div>
  );
}
