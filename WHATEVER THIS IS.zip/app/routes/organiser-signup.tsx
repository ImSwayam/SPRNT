import type { MetaFunction } from "@vercel/remix";

export const meta: MetaFunction = () => {
  return [{ title: "Organiser Sign Up" }];
};

export default function OrganiserSignupPage() {
  return (
    <div className="max-w-md mx-auto">
      <form className="space-y-4 bg-white/90 rounded-xl shadow-card p-6 border border-primary/5">
        <h2 className="text-lg font-semibold text-primary-dark">
          Organiser sign up
        </h2>

        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-700">Name</label>
          <input
            type="text"
            name="name"
            required
            className="w-full rounded-lg border border-slate-200 bg-sand/40 px-3 py-2 text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary"
          />
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-700">Email</label>
          <input
            type="email"
            name="email"
            required
            className="w-full rounded-lg border border-slate-200 bg-sand/40 px-3 py-2 text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary"
          />
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-700">
            Organisation
          </label>
          <input
            type="text"
            name="organisation"
            placeholder="College / Club / Event company"
            required
            className="w-full rounded-lg border border-slate-200 bg-sand/40 px-3 py-2 text-sm outline-none focus:border-primary focus:ring-1 focus:ring-primary"
          />
        </div>

        <div className="space-y-1">
          <label className="text-sm font-medium text-slate-700">
            Organisation proof
          </label>
          <input
            type="file"
            name="organisationProof"
            className="w-full text-xs text-slate-600 file:mr-4 file:py-1 file:px-2 file:rounded-full file:border-0 file:text-xs file:font-semibold file:bg-primary-light/10 file:text-primary-dark hover:file:bg-primary-light/20"
          />
          <p className="text-[10px] text-slate-500">
            Upload a small proof so we can verify your organisation.
          </p>
        </div>

        <div className="pt-2">
          <button
            type="submit"
            className="w-full bg-primary text-white rounded-xl px-4 py-2 hover:bg-primary-dark transition"
          >
            Sign Up
          </button>
        </div>
      </form>
    </div>
  );
}
