import type { MetaFunction } from "@vercel/remix";

export const meta: MetaFunction = () => {
  return [{ title: "My Wallet" }];
};

export default function WalletPage() {
  return (
    <div className="h-full max-h-[calc(100vh-3rem)] overflow-y-auto pr-2">
      <div className="space-y-6">
        <h2 className="text-xl font-semibold text-primary-dark">My Wallet</h2>
        <div className="bg-white/90 rounded-xl shadow-card border border-primary/5 p-6 text-center">
          <h3 className="font-semibold text-primary-dark">
            No tickets yet!
          </h3>
          <p className="text-slate-600 mt-1">
            Your purchased event tickets will appear here.
          </p>
        </div>
        {/* Placeholder content to demonstrate scrolling */}
        <div className="space-y-4">
          {[...Array(10)].map((_, i) => (
            <div
              key={i}
              className="bg-slate-200/50 rounded-xl p-4 animate-pulse"
            >
              <div className="h-4 bg-slate-300/50 rounded w-3/4 mb-3"></div>
              <div className="h-3 bg-slate-300/50 rounded w-1/2"></div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
