import { SignIn } from "@clerk/remix";
import { Link } from "@remix-run/react";
import { GraduationCap, ClipboardUser, ArrowLeft } from "lucide-react";
import { useState } from "react";

type Role = "student" | "organiser" | null;

export default function SignInPage() {
  const [selectedRole, setSelectedRole] = useState<Role>(null);

  const RoleSelector = () => (
    <div className="w-full max-w-4xl mx-auto bg-surface rounded-2xl shadow-lg border border-border overflow-hidden">
      <div className="p-8 md:p-12 text-center">
        <h1 className="text-4xl md:text-5xl font-bold text-text mb-4">
          Join the Hub
        </h1>
        <p className="text-lg text-textSecondary max-w-2xl mx-auto">
          Select your role to get started. Are you here to discover events or to create them?
        </p>
      </div>
      <div className="grid md:grid-cols-2 gap-px bg-border">
        <RoleCard
          icon={GraduationCap}
          title="Student"
          description="Explore events, join clubs, and manage your college experience."
          onClick={() => setSelectedRole("student")}
        />
        <RoleCard
          icon={ClipboardUser}
          title="Organiser"
          description="Create events, manage your club, and engage with your audience."
          onClick={() => setSelectedRole("organiser")}
        />
      </div>
    </div>
  );

  const SignInForm = () => (
    <div className="w-full max-w-md mx-auto flex flex-col items-center">
       <button
        onClick={() => setSelectedRole(null)}
        className="group flex items-center gap-2 text-textSecondary hover:text-text transition-colors mb-6"
      >
        <ArrowLeft className="w-4 h-4 transition-transform group-hover:-translate-x-1" />
        <span>Back to role selection</span>
      </button>
      <div className="text-center mb-8">
         <h2 className="text-3xl font-bold text-text">
            Sign In as {selectedRole === 'student' ? 'a Student' : 'an Organiser'}
        </h2>
        <p className="text-textSecondary mt-2">Welcome back! Please sign in to continue.</p>
      </div>
      <SignIn />
    </div>
  );

  return (
    <div className="min-h-screen w-full bg-background flex items-center justify-center p-4 sm:p-6 lg:p-8">
      <div className="absolute top-6 left-6">
        <Link to="/" className="flex items-center gap-2 text-textSecondary hover:text-text transition-colors">
            <ArrowLeft className="w-4 h-4" />
            <span>Home</span>
        </Link>
      </div>
      <div className="w-full">
        {selectedRole ? <SignInForm /> : <RoleSelector />}
      </div>
    </div>
  );
}

interface RoleCardProps {
  icon: React.ElementType;
  title: string;
  description: string;
  onClick: () => void;
}

function RoleCard({ icon: Icon, title, description, onClick }: RoleCardProps) {
  return (
    <button
      onClick={onClick}
      className="group relative bg-surface p-8 text-left transition-all duration-300 hover:bg-neutral-800 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-background"
    >
      <div className="relative z-10">
        <div className="mb-4">
          <Icon className="w-12 h-12 text-primary" />
        </div>
        <h3 className="text-2xl font-bold text-text mb-2">{title}</h3>
        <p className="text-textSecondary">{description}</p>
      </div>
       <div className="absolute top-4 right-4 text-textSecondary group-hover:text-primary transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6 transition-transform group-hover:translate-x-1 group-hover:-translate-y-1">
                <line x1="7" y1="17" x2="17" y2="7"></line>
                <polyline points="7 7 17 7 17 17"></polyline>
            </svg>
        </div>
    </button>
  );
}
