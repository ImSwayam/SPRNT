import { create } from 'zustand';

// Define the structure for each part of the form
interface BasicInfo {
  title: string;
  category: string;
  shortDescription: string;
  tags: string[];
}

// In a real app, you'd define interfaces for all 10 tabs.
// For brevity, we'll use a generic structure for now.
type FormData = {
  basicInfo: BasicInfo;
  // Add other tab data structures here
  [key: string]: any; 
};

interface EventFormState {
  activeTab: number;
  formData: FormData;
  setFormData: (data: Partial<FormData>) => void;
  setActiveTab: (tabIndex: number) => void;
  nextTab: () => void;
  prevTab: () => void;
}

export const TABS = [
  "Basic Information", "Date & Time", "Location", "Tickets & Pricing",
  "Event Details", "Speakers & Team", "Design & Branding", "Settings & Privacy",
  "Integrations & Add-ons", "Review & Publish"
];

export const useEventFormStore = create<EventFormState>((set) => ({
  activeTab: 0,
  formData: {
    basicInfo: {
      title: '',
      category: 'conference',
      shortDescription: '',
      tags: [],
    },
    // Initialize other tabs with default values
  },
  setFormData: (data) => set((state) => ({
    formData: { ...state.formData, ...data }
  })),
  setActiveTab: (tabIndex) => set({ activeTab: tabIndex }),
  nextTab: () => set((state) => ({
    activeTab: Math.min(state.activeTab + 1, TABS.length - 1)
  })),
  prevTab: () => set((state) => ({
    activeTab: Math.max(state.activeTab - 1, 0)
  })),
}));
