// app/lib/discoverEvents.ts
export type EventStatus = "active" | "past";

export interface DiscoverEvent {
  id: string;
  name: string;
  festivalName: string;
  college: string;
  city: string;
  startDate: string; // ISO
  endDate: string;
  status: EventStatus;
  tags: string[];
  logo: string;
  organiserLogo: string;
}

// Using placeholders from placehold.co as we can't store local assets
export const discoverEvents: DiscoverEvent[] = [
  {
    id: "techfest-2025",
    name: "Techfest 2025–26",
    festivalName: "Techfest",
    college: "IIT Bombay",
    city: "Mumbai",
    startDate: "2025-12-20",
    endDate: "2025-12-23",
    status: "active", // between Oct 2025 and Feb 2026
    tags: ["#tech", "#robotics", "#hackathon"],
    logo: "https://placehold.co/64x64/F5EACB/007C86/png?text=TF",
    organiserLogo: "https://placehold.co/32x32/F5EACB/00515A/png?text=IITB",
  },
  {
    id: "mood-indigo-2025",
    name: "Mood Indigo 2025",
    festivalName: "Mood Indigo",
    college: "IIT Bombay",
    city: "Mumbai",
    startDate: "2025-12-26",
    endDate: "2025-12-29",
    status: "active",
    tags: ["#cultural", "#concerts"],
    logo: "https://placehold.co/64x64/F5EACB/007C86/png?text=MI",
    organiserLogo: "https://placehold.co/32x32/F5EACB/00515A/png?text=IITB",
  },
  {
    id: "sphinx-spce-2026",
    name: "SPHINX 2026",
    festivalName: "SPHINX",
    college: "SPCE",
    city: "Mumbai",
    startDate: "2026-01-10",
    endDate: "2026-01-12",
    status: "active",
    tags: ["#engineering", "#technical"],
    logo: "https://placehold.co/64x64/F5EACB/007C86/png?text=SPX",
    organiserLogo: "https://placehold.co/32x32/F5EACB/00515A/png?text=SPCE",
  },
  {
    id: "spirit-spce-2026",
    name: "SPIRIT 2026",
    festivalName: "SPIRIT",
    college: "SPCE",
    city: "Mumbai",
    startDate: "2026-02-05",
    endDate: "2026-02-07",
    status: "active",
    tags: ["#sports", "#intercollege"],
    logo: "https://placehold.co/64x64/F5EACB/007C86/png?text=SPT",
    organiserLogo: "https://placehold.co/32x32/F5EACB/00515A/png?text=SPCE",
  },
  {
    id: "kshitij-mithibai-2026",
    name: "Kshitij 2026",
    festivalName: "Kshitij",
    college: "Mithibai College",
    city: "Mumbai",
    startDate: "2026-01-24",
    endDate: "2026-01-26",
    status: "active",
    tags: ["#cultural", "#competitions"],
    logo: "https://placehold.co/64x64/F5EACB/007C86/png?text=KSH",
    organiserLogo: "https://placehold.co/32x32/F5EACB/00515A/png?text=MC",
  },
  {
    id: "cad-seminar-spce",
    name: "CAD in Modern Design – Industry Seminar",
    festivalName: "CAD Seminar",
    college: "SPCE",
    city: "Mumbai",
    startDate: "2025-10-15",
    endDate: "2025-10-15",
    status: "active",
    tags: ["#seminar", "#cad", "#mechanical"],
    logo: "https://placehold.co/64x64/F5EACB/007C86/png?text=CAD",
    organiserLogo: "https://placehold.co/32x32/F5EACB/00515A/png?text=SPCE",
  },
  // PAST events (before Oct 2025)
  {
    id: "malhar-xaviers-2025",
    name: "Malhar 2025",
    festivalName: "Malhar",
    college: "St. Xavier's College",
    city: "Mumbai",
    startDate: "2025-08-10",
    endDate: "2025-08-12",
    status: "past",
    tags: ["#cultural", "#litfest"],
    logo: "https://placehold.co/64x64/F5EACB/007C86/png?text=MLH",
    organiserLogo: "https://placehold.co/32x32/F5EACB/00515A/png?text=SXC",
  },
  {
    id: "pratibimb-vjti-2025",
    name: "Pratibimb 2025",
    festivalName: "Pratibimb",
    college: "VJTI",
    city: "Mumbai",
    startDate: "2025-09-05",
    endDate: "2025-09-07",
    status: "past",
    tags: ["#cultural"],
    logo: "https://placehold.co/64x64/F5EACB/007C86/png?text=PRT",
    organiserLogo: "https://placehold.co/32x32/F5EACB/00515A/png?text=VJTI",
  },
];
