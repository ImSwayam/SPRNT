// app/lib/collegeClubs.ts
export interface CollegeClubs {
  college: string;
  city: string;
  clubs: string[];
}

export const collegeClubs: CollegeClubs[] = [
  {
    college: "SPCE (Sardar Patel College of Engineering)",
    city: "Mumbai",
    clubs: [
      "SPCE Racing",
      "WAVE",
      "SPANDAN",
      "TedXSPCE",
      "ROBOCON SPCE",
      "SAE SPCE",
      "SPASHT SPCE",
      "IIIE SPCE",
      "Rotaract Club SPCE",
      "IEEE SPCE",
    ],
  },
  {
    college: "IIT Bombay",
    city: "Mumbai",
    clubs: [
      "IITB Racing",
      "Krittika (Astronomy Club)",
      "Electronics Club",
      "Vaani (Debate Club)",
      "InSync (Dance Club)",
    ],
  },
  // add NM, NMIMS, Xavier's, VJTI, KJ Somaiya etc. here similarly
];
