// app/lib/calendarEvents.ts

export interface CalendarEvent {
  date: number; // Day of the month
  college: string;
  eventName: string;
  logo: string;
  rotation: number; // e.g., -5, 8, -3
  tapeColor: string; // Tailwind color class e.g., 'bg-pink-200/50'
}

// Mock data for December 2025
export const decemberEvents: CalendarEvent[] = [
  {
    date: 4,
    college: "SPCE",
    eventName: "Robotics Workshop",
    logo: "https://placehold.co/100x100/F5EACB/00515A/png?text=SPCE",
    rotation: -4,
    tapeColor: "bg-accent-pink-light/60",
  },
  {
    date: 7,
    college: "Mithibai",
    eventName: "Kshitij Auditions",
    logo: "https://placehold.co/100x100/F5EACB/00515A/png?text=MC",
    rotation: 8,
    tapeColor: "bg-aqua/60",
  },
  {
    date: 12,
    college: "St. Xavier's",
    eventName: "Malhar '26 Launch",
    logo: "https://placehold.co/100x100/F5EACB/00515A/png?text=SXC",
    rotation: 5,
    tapeColor: "bg-sand-dark/40",
  },
  {
    date: 20,
    college: "IIT Bombay",
    eventName: "Techfest Day 1",
    logo: "https://placehold.co/100x100/F5EACB/00515A/png?text=IITB",
    rotation: -6,
    tapeColor: "bg-primary-light/40",
  },
  {
    date: 21,
    college: "IIT Bombay",
    eventName: "Techfest Day 2",
    logo: "https://placehold.co/100x100/F5EACB/00515A/png?text=IITB",
    rotation: 10,
    tapeColor: "bg-primary-light/40",
  },
  {
    date: 26,
    college: "IIT Bombay",
    eventName: "Mood Indigo",
    logo: "https://placehold.co/100x100/F5EACB/00515A/png?text=IITB",
    rotation: -3,
    tapeColor: "bg-yellow-200/60",
  },
  {
    date: 31,
    college: "VJTI",
    eventName: "New Year Bash",
    logo: "https://placehold.co/100x100/F5EACB/00515A/png?text=VJTI",
    rotation: 7,
    tapeColor: "bg-purple-200/60",
  },
];
